package com.tcs.user.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tcs.user.entity.User;
import com.tcs.user.entity.UserResponse;
import com.tcs.user.model.UserRegister;
import com.tcs.user.service.UserService;

@RestController
@RequestMapping("/api/user")
public class UserController {

	@Autowired
	private UserService service;
	
	    @PostMapping("/save")
	    public ResponseEntity<User> saveUser(@RequestBody UserRegister register)
	     {
	        User savedUser = service.saveUser(register);
	        return ResponseEntity.ok(savedUser);
	      }
	    @GetMapping("get/{id}")
	    public ResponseEntity<User> getUserById(@PathVariable int id) {
	       User user = service.getUserById(id);
	        return new ResponseEntity<>(user,HttpStatus.OK);
	    }
	    @GetMapping("getById/{id}")
	    public ResponseEntity<UserResponse> getUserByBooking(@PathVariable int id) {
	       UserResponse user = service.getUserWithBooking(id);
	        return new ResponseEntity<>(user,HttpStatus.OK);
	    }
	
	
}
