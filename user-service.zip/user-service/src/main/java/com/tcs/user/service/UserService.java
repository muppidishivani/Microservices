package com.tcs.user.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.tcs.user.entity.BookingResponse;
import com.tcs.user.entity.User;
import com.tcs.user.entity.UserResponse;
import com.tcs.user.model.UserRegister;
import com.tcs.user.repository.UserRepository;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;

@Service
public class UserService {

	@Autowired
	private UserRepository repository;
	
	@Autowired
	private RestTemplate restTempalte;

    @Value("${booking.service.url}")
    private String bookingServiceUrl;
    
	public User saveUser(UserRegister register) {
		User user=new User();
	   user.setName(register.getName());
	   user.setEmail(register.getEmail());
	   user.setAddress(register.getAddress());
	   user.setPassword(register.getPassword());
	   user.setPhoneNumber(register.getPhoneNumber());
	  
		return repository.save(user);
	}

	public User getUserById(int id) {
		// TODO Auto-generated method stub
		return repository.findById(id).get();
	}

	/* public UserResponse getUserWithBooking(int id) {
	        User user = repository.findById(id).orElseThrow(() -> new RuntimeException("User not found"));
	        Booking booking = restTempalte.getForObject(bookingServiceUrl + id, Booking.class);
	        UserResponse userResponse = new UserResponse();
	        userResponse.setId(user.getId());
	        userResponse.setName(user.getName());
	        userResponse.setEmail(user.getEmail());
	        userResponse.setPassword(user.getPassword());
	        userResponse.setPhoneNumber(user.getPhoneNumber());
	        userResponse.setAddress(user.getAddress());
	        userResponse.setBookingResponse(booking);
	        return userResponse;
	    }*/
	
	
		@CircuitBreaker(name = "bookingService", fallbackMethod = "fallbackGetUserWithBooking")
	    public UserResponse getUserWithBooking(int id) {
	        User user = repository.findById(id).orElseThrow(() -> new RuntimeException("User not found"));
	        BookingResponse booking = restTempalte.getForObject(bookingServiceUrl + id, BookingResponse.class);
	        UserResponse userResponse = new UserResponse();
	        userResponse.setId(user.getId());
	        userResponse.setName(user.getName());
	        userResponse.setEmail(user.getEmail());
	        userResponse.setPassword(user.getPassword());
	        userResponse.setPhoneNumber(user.getPhoneNumber());
	        userResponse.setAddress(user.getAddress());
	        userResponse.setBookingResponse(booking);
	        return userResponse;
	    }

	    public UserResponse fallbackGetUserWithBooking(int id, Throwable t) {
	        User user = repository.findById(id).orElseThrow(() -> new RuntimeException("User not found"));
	        UserResponse userResponse = new UserResponse();
	        userResponse.setId(user.getId());
	        userResponse.setName(user.getName());
	        userResponse.setEmail(user.getEmail());
	        userResponse.setPassword(user.getPassword());
	        userResponse.setPhoneNumber(user.getPhoneNumber());
	        userResponse.setAddress(user.getAddress());

	        // Create a BookingResponse with a custom message indicating service unavailability
	        BookingResponse fallbackBookingResponse = new BookingResponse();
	        fallbackBookingResponse.setMessage("Booking service is currently unavailable. Please try again later.");
	        
	        userResponse.setBookingResponse(fallbackBookingResponse);
	        return userResponse;
	    }
}