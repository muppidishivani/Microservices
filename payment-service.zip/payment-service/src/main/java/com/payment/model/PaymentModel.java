package com.payment.model;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
@Data
@AllArgsConstructor
@NoArgsConstructor

public class PaymentModel {

	
	  private int id;

	    @NotNull
	    private String paymentType; 

	    @NotNull
	    private double amount;

	    @NotNull
	    private String status; // e.g., "SUCCESS", "FAILED"

}
