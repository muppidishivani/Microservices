package com.payment.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.payment.entity.Payment;
import com.payment.model.PaymentModel;
import com.payment.repository.PaymentRepository;

@Service
public class PaymentService {

	@Autowired PaymentRepository repository;
	public Payment savePayment(PaymentModel pmodel)
	{
		Payment payment=new Payment();
		payment.setAmount(pmodel.getAmount());
		payment.setPaymentType(pmodel.getPaymentType());
		payment.setStatus(pmodel.getStatus());
		return repository.save(payment);
	}
	
	public List<Payment> getAll()
	{
		List<Payment> payments=repository.findAll();
		return payments;
	}
	public Payment getOne(int id)
	{
		return repository.findById(id).get();
	}
}
