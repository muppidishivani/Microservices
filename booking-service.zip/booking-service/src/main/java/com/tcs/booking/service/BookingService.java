package com.tcs.booking.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tcs.booking.entity.Booking;
import com.tcs.booking.model.BookingModel;
import com.tcs.booking.repository.BookingRepository;


@Service
public class BookingService {

	@Autowired
	private BookingRepository repository;
	
	public Booking saveUser(BookingModel book) {
		Booking booking=new Booking();
		booking.setBookingDate(book.getBookingDate());
		booking.setBookingDetails(book.getBookingDetails());
		booking.setBookingType(book.getBookingType());
		return repository.save(booking);
	}

	public Booking getUserById(int id) {
		// TODO Auto-generated method stub
		return repository.findById(id).get();
	}
}
