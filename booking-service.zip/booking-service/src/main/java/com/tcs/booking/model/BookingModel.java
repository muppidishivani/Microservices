package com.tcs.booking.model;

import java.sql.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class BookingModel {

	 private Long id;
	    private String userId;
	    private String bookingType; // e.g., flight, hotel, car
	    private String bookingDetails; // JSON string or any other structure to store details
	    private Date bookingDate;
}
